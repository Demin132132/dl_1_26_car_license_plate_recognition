#!/bin/bash
./python train.py --img 640 --batch 16 --epochs 300 --data dataset.yaml --weights yolov5x.pt
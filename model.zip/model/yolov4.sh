#!/bin/bash
./darknet detector train data/obj.data cfg/yolov4-custom.cfg yolov4.conv.137